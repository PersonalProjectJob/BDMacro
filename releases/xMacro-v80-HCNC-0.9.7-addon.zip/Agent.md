# Quy tắc bảo trì xMacro

ZIP này chứa bản chạy cho JX3 v80 Hoàng Cung Nam Chiếu. Khi sửa rotation, làm việc trong cây nguồn xMacro rồi tạo lại ZIP.

1. Lưu mọi file Lua và TXT macro trong `interface/xMacro/` bằng UTF-8 BOM (`EF BB BF`).
2. Sửa profile trong `Schools/<School>/<Profile>.lua` và đồng bộ sang module `Native/XM0x_*.lua` cùng `Runtime.lua`. Giữ alias trong `Core/Macro.lua` và ánh xạ nội công trong `Macro.lua` đồng bộ với `Native/XM07_Dispatch.lua`.
3. Gọi `GetClientPlayer()` và `GetKungfuMount()` bên trong hàm runtime. Giữ nguyên chuỗi `runtimeStatus.nextNative` từ `XM00` đến `XM08`.
4. Chạy `python interface/xMacro/Tools/verify_macro.py --fix` trong cây nguồn và chỉ phát hành sau khi nhận `[PASSED] TẤT CẢ ĐIỀU KIỆN CẦN ĐÃ ĐẠT!`.
5. Giữ cơ chế Key Spam gửi phím qua helper, cùng schema điều khiển và thứ tự nạp. Khi cập nhật BDMacro, đưa hai file Native cùng SHA-256 tương ứng trong `manifest.json` vào cùng một commit. Kiểm tra updater với bản tải đó trước khi đóng gói.
6. Đóng gói theo danh sách file chạy. Loại dữ liệu `*.jx3dat`, log, cache, backup, updater ngoài game, `.git` và mã nguồn bảo trì khỏi gói chia sẻ.
