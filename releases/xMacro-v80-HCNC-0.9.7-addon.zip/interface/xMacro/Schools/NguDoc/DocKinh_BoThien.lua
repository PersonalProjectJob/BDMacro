﻿-- Verified Ngu Doc (Doc Kinh & Bo Thien Quyet) v80 rotations for xMacro.
local DEFAULT_NGUDOC_DOCKINH_MACRO = [[
#name NguDoc_DocKinh_80
#tip Macro Ngu Doc Doc Kinh PVE v80: Uu tien Linh Xa (Ao Kich) > Ngoc Thiem > Thanh Hat + 3 DoT + Hat Tam

-- 0. Bao ve ky nang dan dao & chi ngat Hat Tam khi di chuyen
/config channel-on
/skill [ota:Hạt Tâm,moving] stopota

-- 1. Tu cuu & Sinh ton khi nguy cap
/skill [life<0.5,pet] Cổ Trùng Cuồng Bạo

-- 2. Dieu khien Pet Linh Xa tan cong & Ao Kich (off-GCD)
/skill [pet:Linh Xà] Ảo Kích
/skill [pet] Tấn công

-- 3. Quan ly Pet & Co Trung Hien Te: Uu tien Linh Xa > Ngoc Thiem > Thanh Hat, co pet nao hien te pet do
/skill [nopet,nocd:Linh Xà Dẫn] Linh Xà Dẫn
/skill [nopet,nocd:Ngọc Thiềm Dẫn] Ngọc Thiềm Dẫn
/skill [nopet,nocd:Thánh Hạt Dẫn] Thánh Hạt Dẫn
/skill [pet] Cổ Trùng Hiến Tế
/usependant [buff:Linh Xà Hiến Tế]

-- 4. Co Trung & Ngat chieu Boss (off-GCD)
/skill [tprepare,tnobuff:Mê Tâm Cổ,tnobuff:Đoạt Mệnh Cổ,tnobuff:Khô Tàn Cổ] Mê Tâm Cổ
/skill [tprepare,tbuff:Khô Tàn Cổ] Hạt Tâm
/skill [mana<0.35,nombuff:Khô Tàn Cổ,nombuff:Đoạt Mệnh Cổ] Khô Tàn Cổ
/skill [nombuff:Đoạt Mệnh Cổ,nombuff:Khô Tàn Cổ] Đoạt Mệnh Cổ

-- 5. Chu trinh 3 DoT & Ky nang chu luc Doc Kinh
-- Uu tien Bach Tuc ngay khi hoi chieu (sat thuong tuc thoi + DoT manh nhat)
/skill [nocd:Bách Túc] Bách Túc
-- Duy tri DoT Xa Anh (tranh danh lap khi vua niem Xa Anh)
/skill [nombuff:Xà Ảnh,nolastcast:Xà Ảnh] Xà Ảnh
/skill [mbufftime:Xà Ảnh<2,nolastcast:Xà Ảnh] Xà Ảnh
-- Duy tri DoT Thiem Khieu (hoi mana khi co Đoạt Mệnh Cổ)
/skill [nombuff:Thiềm Khiếu] Thiềm Khiếu

-- 6. Di chuyen (Instant Cast + hoi mana khi co Khô Tàn Cổ)
/skill [moving] Thiên Ti
/skill [mana<0.25,tbuff:Khô Tàn Cổ] Thiên Ti
/skill [moving] Xà Ảnh

-- 7. Filler DPS chinh khi dung yen (van cong 1.75s / 1.5s)
/skill [cd:Bách Túc] Hạt Tâm
]]

local DEFAULT_NGUDOC_BOTHIEN_MACRO = [[
#name NguDoc_BoThien_80
#tip Macro Ngu Doc Bo Thien Quyet v80: Bich Diep + Co Hoac Chung Sinh + Nu Oa + Tuy Vu / Bang Tam

-- 0. Bao ve ky nang dan dao (Thien Diep Tho Thuy 8s)
/config channel-on
/return [ota:Thiên Điệp Thổ Thụy]
/skill [ota:Băng Tàm Khiên Ti,moving] stopota

-- 1. Goi Bich Diep & Sinh ton ban than
/skill [nopet] Bích Điệp Dẫn
/skill [life<0.35] Nữ Oa Vá Trời
/skill [life<0.3,pet] Cổ Trùng Hiến Tế
/skill [mana<0.65,nocombat] Đỉnh Cổ Tiên Vương

-- 2. Cap cuu muc tieu nguy kich (Mau < 35%)
/skill [tlife<0.35] Thánh Thủ Chức Thiên
/skill [tlife<0.45] Thiên Điệp Thổ Thụy

-- 3. Buff Co Hoac Chung Sinh & Burst Nu Oa
/skill [tlife<0.85,tnobuff:Cổ Hoặc Chúng Sinh] Cổ Hoặc Chúng Sinh
/skill [tlife<0.6] Nữ Oa Vá Trời
/usependant [buff:Nữ Oa Vá Trời]

-- 4. Tri lieu khi di chuyen
/skill [moving,tlife<0.9] Thánh Thủ Chức Thiên
/skill [moving,tlife<0.95] Túy Vũ Cửu Thiên

-- 5. Tri lieu don muc tieu & nhom khi dung yen
/skill [tlife<0.75] Băng Tàm Khiên Ti
/skill [tlife<0.95] Túy Vũ Cửu Thiên
/skill Băng Tàm Khiên Ti
]]

local function CreateDocKinh(deps)
    local H = xMacro.Schools.BuildCombatHelpers(deps)
    local tDocKinhState = {
        lastXaAnhFrame = -999,
        lastPetAttackFrame = -999,
        lastAoKichFrame = -999,
        nPetSummonFrame = -999,
        nLastAoKichSuccessFrame = -999,
    }

    local ID_HAT_TAM = {[2209] = true}
    local ID_XA_ANH = {[2210] = true, [2486] = true}
    local ID_THIEM_KHIEU = {[2211] = true, [2490] = true}
    local ID_BACH_TUC = {[2212] = true, [2492] = true, [2496] = true, [5764] = true}
    local ID_DOAT_MENH = {[2214] = true, [2488] = true}
    local ID_ME_TAM = {[2215] = true, [2489] = true, [6247] = true}
    local ID_KHO_TAN = {[2216] = true, [2496] = true}
    local ID_LINH_XA_HIEN_TE = {[2543] = true}
    local ID_THANH_HAT_HIEN_TE = {[2541] = true}
    local ID_NGOC_THIEM_HIEN_TE = {[2542] = true}

    local NAME_XA_ANH = {"Xà Ảnh", "Xa Anh", "蛇影"}
    local NAME_THIEM_KHIEU = {"Thiềm Khiếu", "Thiem Khieu", "蟾啸"}
    local NAME_BACH_TUC = {"Bách Túc", "Bach Tuc", "百足"}
    local NAME_DOAT_MENH = {"Đoạt Mệnh Cổ", "Doat Menh Co", "夺命蛊"}
    local NAME_ME_TAM = {"Mê Tâm Cổ", "Me Tam Co", "迷心蛊"}
    local NAME_KHO_TAN = {"Khô Tàn Cổ", "Kho Tan Co", "枯残蛊"}
    local NAME_LINH_XA_HIEN_TE = {"Linh Xà Hiến Tế", "Linh Xa Hien Te", "灵蛇献祭"}
    local NAME_THANH_HAT_HIEN_TE = {"Thánh Hạt Hiến Tế", "Thanh Hat Hien Te", "圣蝎献祭"}
    local NAME_NGOC_THIEM_HIEN_TE = {"Ngọc Thiềm Hiến Tế", "Ngoc Thiem Hien Te", "玉蟾献祭"}

    local function Run()
        local me = GetClientPlayer()
        if not me then return false end

        local nCurFrame = (GetLogicFrameCount and GetLogicFrameCount()) or 0
        local nStand = (MOVE_STATE and MOVE_STATE.ON_STAND) or 0
        local bMoving = (me.nMoveState or 0) ~= nStand

        local skHatTam = H.ResolveSkill(2209, "Hạt Tâm", "Hat Tam")
        local skXaAnh = H.ResolveSkill(2210, "Xà Ảnh", "Xa Anh")
        local skThiemKhieu = H.ResolveSkill(2211, "Thiềm Khiếu", "Thiem Khieu")
        local skBachTuc = H.ResolveSkill(2212, "Bách Túc", "Bach Tuc")
        local skThienTi = H.ResolveSkill(2213, "Thiên Ti", "Thien Ti")
        local skDoatMenh = H.ResolveSkill(2214, "Đoạt Mệnh Cổ", "Doat Menh Co")
        local skMeTam = H.ResolveSkill(2215, "Mê Tâm Cổ", "Me Tam Co")
        local skKhoTan = H.ResolveSkill(2216, "Khô Tàn Cổ", "Kho Tan Co")
        local skHuyenCo = H.ResolveSkill(2217, "Huyễn Cổ", "Huyen Co")
        local skHuyenThuy = H.ResolveSkill(2220, "Huyền Thủy Cổ", "Huyen Thuy Co")
        local skThanhHat = H.ResolveSkill(2221, "Thánh Hạt Dẫn", "Thanh Hat Dan")
        local skNgocThiem = H.ResolveSkill(2222, "Ngọc Thiềm Dẫn", "Ngoc Thiem Dan")
        local skLinhXa = H.ResolveSkill(2223, "Linh Xà Dẫn", "Linh Xa Dan")
        local skHienTe = H.ResolveSkill(2226, "Cổ Trùng Hiến Tế", "Co Trung Hien Te")
        local skCuongBao = H.ResolveSkill(2227, "Cổ Trùng Cuồng Bạo", "Co Trung Cuong Bao")

        -- 1. Bao ve van cong Hat Tam: chi ngat khi di chuyen
        local bIsPreparing, dwPrepID = false, 0
        if me.GetSkillPrepareState then
            local okP, prep, pid = pcall(function() return me.GetSkillPrepareState() end)
            if okP and prep then bIsPreparing, dwPrepID = true, tonumber(pid) or 0 end
        end
        local okOT, nOT = pcall(function() return me.GetOTActionState() end)
        local bIsOT = okOT and tonumber(nOT or 0) ~= 0
        if bMoving then
            H.ClearChannelLock()
        end
        if bIsPreparing or bIsOT or (not bMoving and H.IsChannelLocked(nCurFrame)) then
            if bMoving and (dwPrepID == skHatTam or ID_HAT_TAM[dwPrepID]) and me.StopCurrentAction then
                pcall(function() return me.StopCurrentAction() end)
            end
            return false
        end

        -- 2. Sinh ton ban than
        local nLife = (me.nMaxLife and me.nMaxLife > 0) and (me.nCurrentLife / me.nMaxLife) or 1
        local nMana = (me.nMaxMana and me.nMaxMana > 0) and (me.nCurrentMana / me.nMaxMana) or 1
        local bHasPet = H.CheckPet and H.CheckPet() or false
        local bHasLinhXa = H.CheckPet and H.CheckPet("Linh Xà|Linh Xa|灵蛇") or false
        local bHasThanhHat = H.CheckPet and H.CheckPet("Thánh Hạt|Thanh Hat|圣蝎") or false
        local bHasNgocThiem = H.CheckPet and H.CheckPet("Ngọc Thiềm|Ngoc Thiem|玉蟾") or false

        if not bHasPet then
            tDocKinhState.lastAoKichFrame = -999
            tDocKinhState.nPetSummonFrame = -999
            tDocKinhState.nLastAoKichSuccessFrame = -999
        elseif tDocKinhState.nPetSummonFrame == -999 then
            tDocKinhState.nPetSummonFrame = nCurFrame
        end

        if nLife < 0.50 and bHasPet and H.IsSkillReady(me, skCuongBao, 24) then
            return H.SendSkill(me, skCuongBao, "Cổ Trùng Cuồng Bạo", false)
        end

        local bHasHienTeBuff = H.FindBuff(me, me, ID_LINH_XA_HIEN_TE, NAME_LINH_XA_HIEN_TE, false) ~= nil
        local bLinhXaReady = H.IsSkillReady(me, skLinhXa, 8)
        local bNgocThiemReady = H.IsSkillReady(me, skNgocThiem, 8)
        local bThanhHatReady = H.IsSkillReady(me, skThanhHat, 8)
        local bHienTeReady = H.IsSkillReady(me, skHienTe, 16)

        -- 3. Quan ly Pet: Uu tien Linh Xa > Ngoc Thiem > Thanh Hat
        if not bHasPet and not bMoving and not H.IsGCD(me) then
            -- a) Uu tien 1: Linh Xa khong CD -> Luon goi Linh Xa
            if bLinhXaReady then
                return H.SendSkill(me, skLinhXa, "Linh Xà Dẫn", bHasHienTeBuff)
            -- b) Uu tien 2: Linh Xa dang CD -> Goi Ngoc Thiem (ID 2222)
            elseif bNgocThiemReady then
                return H.SendSkill(me, skNgocThiem, "Ngọc Thiềm Dẫn", false)
            -- c) Uu tien 3: Ca Linh Xa & Ngoc Thiem deu CD -> Goi Thanh Hat (ID 2221)
            elseif bThanhHatReady then
                return H.SendSkill(me, skThanhHat, "Thánh Hạt Dẫn", false)
            end
        end

        local tar = H.GetCurrentTargetObject and H.GetCurrentTargetObject() or nil
        if tar and tar.nCurrentLife and tar.nCurrentLife <= 0 then tar = nil end

        -- 4. Dieu khien Pet Linh Xa: LUON O CHE DO SPAM (off-GCD, khong chen GCD nhan vat)
        if bHasLinhXa then
            local atkSkillID = (H.GetPetSkill and H.GetPetSkill("Tấn công")) or 2472
            pcall(OnAddOnUseSkill, atkSkillID, 1)

            local aoKichID = (H.GetPetSkill and (H.GetPetSkill("Ảo Kích") or H.GetPetSkill("Ao Kich") or H.GetPetSkill("Huyễn Kích"))) or 2477
            pcall(OnAddOnUseSkill, aoKichID, 1)
        elseif bHasPet then
            local atkSkillID = (H.GetPetSkill and H.GetPetSkill("Tấn công")) or 2472
            pcall(OnAddOnUseSkill, atkSkillID, 1)
        end

        -- 5. Co Trung Hien Te: Co bat ky pet nao thi hien te ngay khi Hien Te san sang (khong uu tien hay tri hoan rieng cho Linh Xa)
        if bHasPet and bHienTeReady and not bHasHienTeBuff then
            if H.SendSkill(me, skHienTe, "Cổ Trùng Hiến Tế", bHasLinhXa) then
                return true
            end
        end

        if not tar then return false end

        -- 4. Co Trung & Ngat chieu Boss (off-GCD)
        local bHasDoatMenh = H.FindBuff(tar, me, ID_DOAT_MENH, NAME_DOAT_MENH, true) ~= nil
        local bHasKhoTan = H.FindBuff(tar, me, ID_KHO_TAN, NAME_KHO_TAN, true) ~= nil
        local bHasMeTam = H.FindBuff(tar, me, ID_ME_TAM, NAME_ME_TAM, true) ~= nil
        local bTargetPreparing = H.CheckPrepare and H.CheckPrepare(tar) or false

        if bTargetPreparing and not bHasDoatMenh and not bHasKhoTan and not bHasMeTam and H.IsSkillReady(me, skMeTam, 24) then
            H.SendSkill(me, skMeTam, "Mê Tâm Cổ", false)
        elseif nMana < 0.35 and not bHasDoatMenh and not bHasKhoTan and H.IsSkillReady(me, skKhoTan, 24) then
            H.SendSkill(me, skKhoTan, "Khô Tàn Cổ", false)
        elseif not bHasDoatMenh and not bHasKhoTan and H.IsSkillReady(me, skDoatMenh, 24) then
            H.SendSkill(me, skDoatMenh, "Đoạt Mệnh Cổ", false)
        end

        if H.IsGCD(me) then return false end

        -- 5. Chu trinh 3 DoT & Ky nang chu luc Doc Kinh
        -- a) Bach Tuc: Uu tien so 1 ngay khi hoi chieu (luon dat thang vao target)
        if H.IsSkillReady(me, skBachTuc, 8) then
            return H.SendSkill(me, skBachTuc, "Bách Túc", bHasHienTeBuff)
        end

        -- b) Xa Anh: Duy tri DoT 12s (chong danh lap khi vua niem < 1.5s)
        local bXaAnh = H.FindBuff(tar, me, ID_XA_ANH, NAME_XA_ANH, true)
        local nXaAnhLeft = bXaAnh and H.BuffRemainingSec(bXaAnh) or 0
        local bRecentXaAnh = (lastcast and lastcast(skXaAnh)) or ((nCurFrame - tDocKinhState.lastXaAnhFrame) < 24)
        if (not bXaAnh or nXaAnhLeft < 2.0) and not bRecentXaAnh and H.IsSkillReady(me, skXaAnh, 8) then
            if H.SendSkill(me, skXaAnh, "Xà Ảnh", bHasHienTeBuff) then
                tDocKinhState.lastXaAnhFrame = nCurFrame
                return true
            end
        end

        -- c) Thiem Khieu: Duy tri DoT 12s & hoi mana khi co Doat Menh Co
        local bThiemKhieu = H.FindBuff(tar, me, ID_THIEM_KHIEU, NAME_THIEM_KHIEU, true)
        local nThiemKhieuLeft = bThiemKhieu and H.BuffRemainingSec(bThiemKhieu) or 0
        if (not bThiemKhieu or nThiemKhieuLeft < 2.0) and H.IsSkillReady(me, skThiemKhieu, 8) then
            return H.SendSkill(me, skThiemKhieu, "Thiềm Khiếu", bHasHienTeBuff)
        end

        -- d) Di chuyen hoac can hut mana voi Kho Tan Co -> Thien Ti / Xa Anh
        if (bMoving or (nMana < 0.25 and bHasKhoTan)) and H.IsSkillReady(me, skThienTi, 8) then
            return H.SendSkill(me, skThienTi, "Thiên Ti", false)
        end
        if bMoving and H.IsSkillReady(me, skXaAnh, 8) then
            return H.SendSkill(me, skXaAnh, "Xà Ảnh", false)
        end

        -- e) Filler dung yen: Hat Tam (1.75s / 1.5s)
        -- TUYET DOI khong dung Hat Tam neu Bach Tuc dang san sang (CD <= 0) hoac vua cast trong vong 625ms
        local bBachTucReady = false
        if me.GetSkillCDProgress then
            local okCD, bCool, nLeft = pcall(function() return me.GetSkillCDProgress(skBachTuc, 1) end)
            if okCD and (not bCool or tonumber(nLeft or 0) <= 0) then
                bBachTucReady = true
            end
        end
        local nLastBT = tSkillCastFrame and tSkillCastFrame[skBachTuc] or -999
        local bBTPending = (nCurFrame - nLastBT) >= 0 and (nCurFrame - nLastBT) < 10

        if not bMoving and not bBachTucReady and not bBTPending and H.IsSkillReady(me, skHatTam, 4) then
            return H.SendSkill(me, skHatTam, "Hạt Tâm", bHasHienTeBuff)
        end

        return false
    end

    return {run = Run, defaultScript = DEFAULT_NGUDOC_DOCKINH_MACRO}
end

local function CreateBoThien(deps)
    local H = xMacro.Schools.BuildCombatHelpers(deps)

    local ID_CO_HOAC = {[2236] = true}
    local ID_NU_OA = {[2230] = true}
    local NAME_CO_HOAC = {"Cổ Hoặc Chúng Sinh", "Co Hoac Chung Sinh", "蛊惑众生"}
    local NAME_NU_OA = {"Nữ Oa Vá Trời", "Nu Oa Va Troi", "女娲补天"}

    local function Run()
        local me = GetClientPlayer()
        if not me then return false end

        local nStand = (MOVE_STATE and MOVE_STATE.ON_STAND) or 0
        local bMoving = (me.nMoveState or 0) ~= nStand

        local skBichDiep = H.ResolveSkill(2965, "Bích Điệp Dẫn", "Bich Diep Dan")
        local skNuOa = H.ResolveSkill(2230, "Nữ Oa Vá Trời", "Nu Oa Va Troi")
        local skBangTam = H.ResolveSkill(2231, "Băng Tàm Khiên Ti", "Bang Tam Khien Ti")
        local skTuyVu = H.ResolveSkill(2232, "Túy Vũ Cửu Thiên", "Tuy Vu Cuu Thien")
        local skThanhThu = H.ResolveSkill(2233, "Thánh Thủ Chức Thiên", "Thanh Thu Chuc Thien")
        local skDinhCo = H.ResolveSkill(2234, "Đỉnh Cổ Tiên Vương", "Dinh Co Tien Vuong")
        local skThienDiep = H.ResolveSkill(2235, "Thiên Điệp Thổ Thụy", "Thien Diep Tho Thuy")
        local skCoHoac = H.ResolveSkill(2236, "Cổ Hoặc Chúng Sinh", "Co Hoac Chung Sinh")
        local skHienTe = H.ResolveSkill(2226, "Cổ Trùng Hiến Tế", "Co Trung Hien Te")

        -- 1. Bao ve Thien Diep Tho Thuy & Bang Tam Khien Ti
        local bIsPreparing, dwPrepID = false, 0
        if me.GetSkillPrepareState then
            local okP, prep, pid = pcall(function() return me.GetSkillPrepareState() end)
            if okP and prep then bIsPreparing, dwPrepID = true, tonumber(pid) or 0 end
        end
        local okOT, nOT = pcall(function() return me.GetOTActionState() end)
        local bIsOT = okOT and tonumber(nOT or 0) ~= 0
        if bIsPreparing or bIsOT then
            if bMoving and dwPrepID == skBangTam and me.StopCurrentAction then
                pcall(function() return me.StopCurrentAction() end)
            end
            return false
        end

        local nLife = (me.nMaxLife and me.nMaxLife > 0) and (me.nCurrentLife / me.nMaxLife) or 1
        local nMana = (me.nMaxMana and me.nMaxMana > 0) and (me.nCurrentMana / me.nMaxMana) or 1
        local bHasPet = H.CheckPet and H.CheckPet() or false

        -- 2. Goi Bich Diep & Sinh ton
        if not bHasPet and not bMoving and not H.IsGCD(me) and H.IsSkillReady(me, skBichDiep, 16) then
            return H.SendSkill(me, skBichDiep, "Bích Điệp Dẫn", false)
        end
        if nLife < 0.30 and bHasPet and H.IsSkillReady(me, skHienTe, 24) then
            return H.SendSkill(me, skHienTe, "Cổ Trùng Hiến Tế", true)
        end
        if nLife < 0.40 and H.IsSkillReady(me, skNuOa, 24) then
            return H.SendSkill(me, skNuOa, "Nữ Oa Vá Trời", true)
        end

        local tar = (H.GetCurrentTargetObject and H.GetCurrentTargetObject()) or me
        local nTarLife = (tar and tar.nMaxLife and tar.nMaxLife > 0) and (tar.nCurrentLife / tar.nMaxLife) or nLife

        if H.IsGCD(me) then return false end

        -- 3. Cap cuu nguy kich
        if nTarLife < 0.40 and H.IsSkillReady(me, skThanhThu, 16) then
            return H.SendSkill(me, skThanhThu, "Thánh Thủ Chức Thiên", true)
        end
        if nTarLife < 0.45 and not bMoving and H.IsSkillReady(me, skThienDiep, 24) then
            return H.SendSkill(me, skThienDiep, "Thiên Điệp Thổ Thụy", true)
        end

        -- 4. Duy tri Co Hoac Chung Sinh & Nu Oa Va Troi
        local bHasCoHoac = H.FindBuff(tar, me, ID_CO_HOAC, NAME_CO_HOAC, false) ~= nil
        if nTarLife < 0.85 and not bHasCoHoac and H.IsSkillReady(me, skCoHoac, 24) then
            return H.SendSkill(me, skCoHoac, "Cổ Hoặc Chúng Sinh", false)
        end
        if nTarLife < 0.65 and H.IsSkillReady(me, skNuOa, 24) then
            return H.SendSkill(me, skNuOa, "Nữ Oa Vá Trời", true)
        end

        local bHasNuOa = H.FindBuff(me, me, ID_NU_OA, NAME_NU_OA, false) ~= nil

        -- 5. Tri lieu khi di chuyen
        if bMoving then
            if nTarLife < 0.85 and H.IsSkillReady(me, skThanhThu, 16) then
                return H.SendSkill(me, skThanhThu, "Thánh Thủ Chức Thiên", bHasNuOa)
            end
            if H.IsSkillReady(me, skTuyVu, 8) then
                return H.SendSkill(me, skTuyVu, "Túy Vũ Cửu Thiên", bHasNuOa)
            end
            return false
        end

        -- 6. Tri lieu khi dung yen
        if nMana < 0.65 and not me.bFightState and H.IsSkillReady(me, skDinhCo, 32) then
            return H.SendSkill(me, skDinhCo, "Đỉnh Cổ Tiên Vương", false)
        end
        if nTarLife < 0.75 and H.IsSkillReady(me, skBangTam, 4) then
            return H.SendSkill(me, skBangTam, "Băng Tàm Khiên Ti", bHasNuOa)
        end
        if nTarLife < 0.95 and H.IsSkillReady(me, skTuyVu, 8) then
            return H.SendSkill(me, skTuyVu, "Túy Vũ Cửu Thiên", bHasNuOa)
        end
        if H.IsSkillReady(me, skBangTam, 4) then
            return H.SendSkill(me, skBangTam, "Băng Tàm Khiên Ti", bHasNuOa)
        end

        return false
    end

    return {run = Run, defaultScript = DEFAULT_NGUDOC_BOTHIEN_MACRO}
end

-- Publish deferred factories; module loading does not require Core or Registry yet.
xMacro = xMacro or {}
xMacro.SchoolFactories = xMacro.SchoolFactories or {}
xMacro.SchoolFactories.NguDoc = xMacro.SchoolFactories.NguDoc or {}
if xMacro.SchoolProfiles and xMacro.SchoolProfiles.NguDoc then
    xMacro.SchoolProfiles.NguDoc.DocKinh = nil
    xMacro.SchoolProfiles.NguDoc.BoThien = nil
end
xMacro.SchoolFactories.NguDoc.DocKinh = CreateDocKinh
xMacro.SchoolFactories.NguDoc.BoThien = CreateBoThien
