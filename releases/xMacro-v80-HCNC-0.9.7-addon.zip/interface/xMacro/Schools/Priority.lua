﻿-- Shared guard for PvE damage scripts in the Hoang Cung Nam Chieu client.
function xMacro.Schools.RegisterDamageScript(school, profile, scriptsByMount)
    local factories = xMacro.SchoolFactories
    factories[school] = factories[school] or {}
    factories[school][profile] = function(deps)
        local function Run()
            local player = GetClientPlayer and GetClientPlayer()
            if not player or not player.GetKungfuMount or not player.GetSkillLevel or player.bDeathFlag then
                return false
            end
            local mount = player.GetKungfuMount and player.GetKungfuMount()
            local kungfuID = mount and (mount.dwSkillID or mount.dwMountKungfuID) or (type(mount) == "number" and mount)
            if kungfuID then kungfuID = tonumber(kungfuID) or kungfuID end
            local script = kungfuID and (scriptsByMount[kungfuID] or (type(kungfuID) == "number" and scriptsByMount[tostring(kungfuID)]))
            if not script then
                for _, s in pairs(scriptsByMount) do
                    if type(s) == "string" or type(s) == "function" then
                        script = s
                        break
                    end
                end
            end
            if not script then return false end

            local target = deps.GetCurrentTargetObject()
            if not target or not target.dwID or target.dwID == player.dwID or target.bDeathFlag then
                return false
            end
            if IsEnemy and not IsEnemy(player.dwID, target.dwID) then return false end
            if type(script) == "function" then script = script(player) end
            -- The generic numeric /skill or /cast handler accepts unknown IDs at level 1.
            -- Skip unlearned skills so the client can fall through to the next priority.
            script = script:gsub("(/[a-z]+%s+[^\r\n]+)", function(command)
                local cmd, body = command:match("^/([a-z]+)%s+(.*)$")
                if cmd == "skill" or cmd == "cast" or cmd == "fcast" then
                    local skillTarget = body:match("%]%s*(.-)%s*$") or body:match("^%s*(.-)%s*$")
                    if skillTarget and skillTarget ~= "" then
                        local skillID = tonumber(skillTarget)
                        if skillID and (player.GetSkillLevel(skillID) or 0) <= 0 then
                            return ""
                        end
                    end
                end
                return command
            end)
            -- A previous profile may have left its /config before filter active.
            return ExecuteMacroCommand("/config before:null\n" .. script)
        end
        return {run = Run}
    end
    if xMacro.SchoolProfiles[school] then xMacro.SchoolProfiles[school][profile] = nil end
end
