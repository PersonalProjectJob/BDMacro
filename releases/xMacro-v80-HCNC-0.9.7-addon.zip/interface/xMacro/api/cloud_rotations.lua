﻿return {
    version = "20261108.1",
    timestamp = "2026-11-08 13:45:00",
    client = "JX3-v80",
    rotations = {
        [10002] = {
            school = "ThieuLam",
            profile = "TayTuyKinh",
            name = "ThieuLam_TayTuyKinh_80",
            script = [[
#name ThieuLam_TayTuyKinh_80
/skill [life<0.35] 235
/skill [distance<=4,rage>=3] 247
/skill [distance<=4] 237
/skill [distance<=4] 242
/skill [distance<=4] 241
/skill [distance<=4] 240
]]
        },
        [10003] = {
            school = "ThieuLam",
            profile = "DichCanKinh",
            name = "ThieuLam_DichCanKinh_80",
            script = [[
#name ThieuLam_DichCanKinh_80
/skill [life<0.30] 235
/skill [distance<=4,rage>=3] 238
/skill [distance<=4,rage>=3] 246
/skill [distance<=4] 243
/skill [distance<=4] 242
/skill [distance<=4] 241
/skill [distance<=4] 240
]]
        },
        [10014] = {
            school = "ThuanDuong",
            profile = "TuHaCong",
            name = "ThuanDuong_TuHa_80",
            script = [[
#name ThuanDuong_TuHa_80
/skill [life<0.35] 365
/skill [nobuff:373] 357
/skill [qidian>=8] 362
/skill [distance<=20] 368
/skill [distance<=20] 367
/skill [distance<=20] 361
]]
        },
        [10015] = {
            school = "ThuanDuong",
            profile = "ThaiHuKiemY",
            name = "ThuanDuong_ThaiHu_80",
            script = [[
#name ThuanDuong_ThaiHu_80
/skill [life<0.35] 365
/skill [nobuff:373] 357
/skill [distance<=4,qidian>=8] 359
/skill [distance<=4,qidian>=7] 360
/skill [distance<=4] 364
/skill [distance<=4] 358
]]
        },
        [10021] = {
            school = "VanHoa",
            profile = "HoaGian",
            name = "VanHoa_HoaGian_80",
            script = [[
#name VanHoa_HoaGian_80
/skill [life<0.30] 132
/skill [tbuff:LanThoi,tbuff:ThuongDuongKiem,tbuff:ChungLam] 140
/skill [tnobuff:LanThoi] 139
/skill [tnobuff:ThuongDuongKiem] 141
/skill [tnobuff:ChungLam] 143
/skill [distance<=20] 138
/skill [distance<=20] 142
]]
        },
        [10026] = {
            school = "ThienSach",
            profile = "DPS",
            name = "ThienSach_NgaoHuyet_80",
            script = [[
#name ThienSach_NgaoHuyet_80
/skill [life<0.35] 424
/skill [life<0.45] 414
/skill [distance<=4,tbuff:LuuTuyen>=3] 422
/skill [distance<=4] 403
/skill [distance<=4] 404
/skill [distance<=4] 401
]]
        },
        [10062] = {
            school = "ThienSach",
            profile = "ThietLao",
            name = "ThienSach_ThietLao_80",
            script = [[
#name ThienSach_ThietLao_80
/skill [life<0.30] 424
/skill [life<0.40] 414
/skill [distance<=4] 415
/skill [distance<=4] 403
/skill [distance<=4] 418
/skill [distance<=4] 404
/skill [distance<=4] 401
]]
        },
        [10081] = {
            school = "ThatTu",
            profile = "BangTam",
            name = "ThatTu_BangTam_80",
            script = [[
#name ThatTu_BangTam_80
/skill [life<0.30] 539
/skill [distance<=20,tbuff:CapKhuc>=3] 547
/skill [distance<=20,tbuff:CapKhuc>=3] 549
/skill [distance<=20] 544
/skill [distance<=20] 541
/skill [distance<=20] 548
]]
        },
        [10144] = {
            school = "TangKiem",
            profile = "DPS",
            name = "TangKiem_VanThuy_80",
            script = [[
#name TangKiem_VanThuy_80
/skill [rage>=80] 1600
/skill [distance<=4] 1583
/skill [distance<=4] 1584
/skill [distance<=4] 1580
]]
        },
        [10145] = {
            school = "TangKiem",
            profile = "DPS",
            name = "TangKiem_SonCu_80",
            script = [[
#name TangKiem_SonCu_80
/skill [rage<20] 1599
/skill [distance<=4] 1656
/skill [distance<=4] 1657
/skill [distance<=4] 1658
]]
        },
        [10175] = {
            school = "NguDoc",
            profile = "DocKinh",
            name = "NguDoc_DocKinh_80",
            script = [[
#name NguDoc_DocKinh_80
/skill [life<0.30] 2216
/skill [nopet] 2214
/skill [pet:snake] 2226
/skill [tnobuff:XaDoc] 2220
/skill [tnobuff:BachTuc] 2217
/skill [distance<=20] 2218
/skill [distance<=20] 2215
]]
        },
        [10176] = {
            school = "NguDoc",
            profile = "BoThien",
            name = "NguDoc_BoThien_80",
            script = [[
#name NguDoc_BoThien_80
/skill [life<0.30] 2216
/skill [nopet] 2214
/skill [distance<=20] 2218
/skill [distance<=20] 2215
]]
        },
        [10224] = {
            school = "DuongMon",
            profile = "KinhVu",
            name = "DuongMon_KinhVu_80",
            script = [[
#name DuongMon_KinhVu_80
/skill [life<0.35] 3105
/skill [distance<=25,tm>=40] 3093
/skill [distance<=25] 3096
/skill [distance<=25] 3098
/skill [distance<=25] 3091
]]
        },
        [10225] = {
            school = "DuongMon",
            profile = "ThienLa",
            name = "DuongMon_ThienLa_80",
            script = [[
#name DuongMon_ThienLa_80
/skill [life<0.35] 3105
/skill [distance<=20] 3109
/skill [distance<=20] 3110
/skill [distance<=20] 3108
/skill [distance<=20] 3106
]]
        },
        [10242] = {
            school = "MinhGiao",
            profile = "PhanAnh",
            name = "MinhGiao_PhanAnh_80",
            script = [[
#name MinhGiao_PhanAnh_80
/skill [life<0.30] 3965
/skill [distance<=5,fullsun] 3967
/skill [distance<=5,fullmoon] 3967
/skill [distance<=5,xmbuff:4052] 3979
/skill [distance<=5] 3963
/skill [distance<=5] 3960
/skill [distance<=5,sun>=moon] 3962
/skill [distance<=5] 3959
]]
        },
        [10243] = {
            school = "MinhGiao",
            profile = "MinhTon",
            name = "MinhGiao_MinhTon_80",
            script = [[
#name MinhGiao_MinhTon_80
/skill [life<0.30] 3965
/skill [life<0.40,fullsun] 3966
/skill [distance<=5] 3972
/skill [distance<=8] 3973
/skill [distance<=5] 3975
/skill [distance<=5,fullsun] 3967
/skill [distance<=5,fullmoon] 3967
/skill [distance<=5,sun>=moon] 3960
/skill [distance<=5,moon>sun] 3963
/skill [distance<=5,sun>=moon] 3959
/skill [distance<=5] 3962
]]
        }
    }
}
