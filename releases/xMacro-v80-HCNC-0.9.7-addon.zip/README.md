# xMacro 0.9.7 cho JX3 v80 Hoàng Cung Nam Chiếu

## Cài addon

1. Thoát game. Nếu đã dùng xMacro, sao lưu `interface/xMacro` trước khi chép đè.
2. Giải nén ZIP vào thư mục có `jx3client.exe` để game thấy `interface/xMacro/info.ini`.
3. Mở game bằng launcher gốc. Bật **xMacro** trong danh sách addon nếu từng tắt. Khi cần, mở bảng xMacro từ HM/AIO.
4. Tạo vi lệnh `/script xMacro.Run()` và gán phím để chạy một lượt theo nội công đang bật. Vi lệnh cũ `/script macro()` vẫn dùng được.

## Key Spam tùy chọn

Nếu muốn gửi phím lặp, mở `interface/xMacro/KeySpam.exe` hoặc `start_xmacro.bat` trên Windows x64. Gán phím cho vi lệnh trong game, nhập phím đó vào bảng Key Spam và chọn **Bắt đầu**. Giữ helper mở trong lúc dùng. Khi helper tắt, bạn vẫn có thể tự bấm vi lệnh.

Addon dùng bộ Native đi kèm. Để cập nhật, thoát game và chép đè từ ZIP mới. Bản rotation này lấy từ [BDMacro 48e1ef2](https://github.com/PersonalProjectJob/BDMacro/commit/48e1ef202e49f2be06f1fdfae392f296daf4366d).

## Profile và alias

Dùng `/script xMacro.Run("TS")` để chọn một profile cụ thể.

| Alias | Profile |
| --- | --- |
| `VH` | Vạn Hoa Hoa Gian |
| `ND`, `NDDK`, `NDBT` | Ngũ Độc Độc Kinh, Bổ Thiên |
| `7T` | Thất Tú Băng Tâm |
| `TS` | Thiên Sách Ngạo Huyết |
| `TK` | Tàng Kiếm Vấn Thủy, Sơn Cư |
| `DMKV`, `DMTL` | Đường Môn Kinh Vũ, Thiên La |
| `MG` | Minh Giáo Phần Ảnh |
| `TL` | Thiếu Lâm Dịch Cân Kinh |
| `TDTH`, `TDTK` | Thuần Dương Tử Hà Công, Thái Hư Kiếm Ý |

Thiên La đặt bẫy và nỏ thủ công. Các profile DPS mới đã qua mô phỏng Lua 5.1, chưa xác nhận trong trận.

