# xMacro 0.9.7 cho JX3 v80 Hoàng Cung Nam Chiếu

## Cài addon

1. Thoát game. Nếu đã dùng xMacro, sao lưu `interface/xMacro` trước khi chép đè.
2. Giải nén ZIP vào thư mục có `jx3client.exe` để game thấy `interface/xMacro/info.ini`.
3. Mở game bằng launcher gốc. Bật **xMacro** trong danh sách addon nếu từng tắt. Khi cần, mở bảng xMacro từ HM/AIO.
4. Tạo vi lệnh `/xmacro` (hoặc `/xm`) và gán phím: hệ thống tự động nhận diện nội công đang kích hoạt và chạy đúng macro tương ứng. Các vi lệnh cũ như `/script xMacro.Run()` hay `/script macro()` vẫn dùng được bình thường.

## Key Spam tùy chọn

Nếu muốn gửi phím lặp, mở `interface/xMacro/KeySpam.exe` hoặc `start_xmacro.bat` trên Windows x64. Gán phím cho vi lệnh trong game, nhập phím đó vào bảng Key Spam và chọn **Bắt đầu**. Giữ helper mở trong lúc dùng. Khi helper tắt, bạn vẫn có thể tự bấm vi lệnh.

Addon dùng bộ Native đi kèm. Để cập nhật, thoát game và chép đè từ ZIP mới.

## Profile và alias

Mặc định `/xmacro` tự nhận diện theo nội công. Nếu muốn chỉ định một profile cụ thể, dùng `/xmacro <alias>` (ví dụ `/xmacro TS`) hoặc `/script xMacro.Run("TS")`.

| Alias | Profile |
| --- | --- |
| `VH` | Vạn Hoa Hoa Gian |
| `ND`, `NDDK`, `NDBT` | Ngũ Độc Độc Kinh, Bổ Thiên |
| `7T` | Thất Tú Băng Tâm |
| `TS` | Thiên Sách Ngạo Huyết |
| `TK` | Tàng Kiếm Vấn Thủy, Sơn Cư |
| `DMKV`, `DMTL` | Đường Môn Kinh Vũ, Thiên La |
| `MG` | Minh Giáo Phần Ảnh |
| `TL` | Thiếu Lâm Dịch Cân Kinh |
| `TDTH`, `TDTK` | Thuần Dương Tử Hà Công, Thái Hư Kiếm Ý |

Thiên La đặt bẫy và nỏ thủ công. Các profile DPS mới đã qua mô phỏng Lua 5.1, chưa xác nhận trong trận.

